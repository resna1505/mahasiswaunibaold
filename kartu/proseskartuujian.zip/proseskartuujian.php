<?php
if (!file_exists("../nilai/ttd.cfg")) {
	@touch("../nilai/ttd.cfg");
}
$arrayttd=file("../nilai/ttd.cfg");
$nipdirektur=trim($arrayttd[0]);
$namadirektur=trim($arrayttd[1]);
$nipkabag=trim($arrayttd[2]);
$namakabag=trim($arrayttd[3]);
$jabatandirektur=trim($arrayttd[4]);
$jabatankabag=trim($arrayttd[5]);

$namabaak=trim($arrayttd[6]);
$jabatanbaak=trim($arrayttd[7]);
$nipbaak=trim($arrayttd[8]);
 $q="SELECT mahasiswa.*,
 prodi.NAMA as NAMAP ,prodi.TINGKAT,
 mspst.NOMBAMSPST ,
 fakultas.NAMA as NAMAF, 
 fakultas.NAMAPIMPINAN as DEKAN 
 FROM mahasiswa,prodi,departemen,fakultas,mspst
WHERE 1=1 
AND
mahasiswa.IDPRODI=prodi.ID
AND
departemen.ID=prodi.IDDEPARTEMEN
AND
departemen.IDFAKULTAS=fakultas.ID
AND
mspst.IDX=prodi.ID
AND mahasiswa.ID='$idmahasiswaupdate'
 ";

$h=doquery($q,$koneksi);
if (sqlnumrows($h)>0) {
  $d=sqlfetcharray($h); 
}
 
echo "
<table width=650 style='page-break-after:always;'>
  <tr>
    <td align=center colspan=2><b>$namakantor</td>
  </tr>
  <tr>
    <td align=center colspan=2><br><b>KARTU UJIAN $jenis ".$arraysemester[$semesterupdate]." ".($tahunupdate-1)."/$tahunupdate<br><br></td>
  </tr>
  <tr valign=top>
    <td align=center>
    
    <table width=100% >
      <tr>
        <td>NPM</td>
        <td>:</td>
        <td>$idmahasiswaupdate</td>
      </tr>
      <tr>
        <td>NAMA</td>
        <td>:</td>
        <td>$d[NAMA]</td>
      </tr>
      <tr>
        <td>TA</td>
        <td>:</td>
        <td>".$arraysemester[$semesterupdate]." ".($tahunupdate-1)."/$tahunupdate</td>
      </tr>
    </table>
    
    </td>
    <td align=center>
    <table  >
      <tr>
        <td>FAKULTAS</td>
        <td>:</td>
        <td>$d[NAMAF]</td>
      </tr>
      <tr>
        <td>JURUSAN</td>
        <td>:</td>
        <td>$d[NAMAP]</td>
      </tr>
        <tr>
        <td>JENJANG</td>
        <td>:</td>
        <td>".$arrayjenjang[$d[TINGKAT]]."</td>
      </tr>
 
    </table>
    
    </td>


  </tr>
  <tr>
    <td colspan=2 align=center>
    ";
    $q="
    				SELECT 
				pengambilanmk.*,
				makul.NAMA,
				SKSMAKUL AS SKS
				FROM pengambilanmk,makul
				WHERE
				pengambilanmk.IDMAHASISWA='$idmahasiswaupdate'
				AND pengambilanmk.IDMAKUL=makul.ID
				AND pengambilanmk.SEMESTER='$semesterupdate'
				AND pengambilanmk.TAHUN='$tahunupdate'
				ORDER BY 
				pengambilanmk.IDMAKUL

    ";
    $h2=doquery($q,$koneksi);
    if (sqlnumrows($h2)>0) {
      $semesterx=((($tahunupdate-1-$d[ANGKATAN])*2)+$semesterupdate);
      echo "
        <br><Br> 
      <table border=1 width=100% style='border-collapse:collapse;'>
        <tr align=center style='font-weight:bold;'>
          <td>NO</td>
          <td>KODE MK</td>
          <td>MATA KULIAH</td>
          <td>SKS</td>
          <td>SMT</td>
          <td>KELAS</td>
          <td>TT. PENGAWAS</td>
        </tr>
      ";
      $i=0;
      $totalsks=0;
      while ($d2=sqlfetcharray($h2)) {
        $i++;
        
        //$semesterx
      echo "
        <tr>
          <td align=center>$i</td>
          <td>$d2[IDMAKUL]</td>
          <td nowrap>$d2[NAMA]</td>
          <td align=center>$d2[SKS]</td>
          <td align=center>$d2[SEMESTERMAKUL]</td>
          <td align=center>$d2[KELAS]</td>
          <td></td>
        </tr>
      ";
      $totalsks+=$d2[SKS];

      }
      echo "
        <tr>
          <td colspan=3><b>JUMLAH SKS DIAMBIL</td>
          <td align=center><b>$totalsks</td>
          <td ></td>
          <td></td>
          <td></td>
        </tr>
      ";
      echo "</table>";
    }
    echo "
    
    </td>
  </tr>
  <tr valign=top>
    <td align=center colspan=2>
    <br><Br><Br>
    <table  width=100%>
      <tr valign=top>
        <td width=30%>
        
        
        </td>
 
        <td> </td>
 
        <td width=30%>$lokasikantor, $w[mday] ".$arraybulan[$w[mon]-1]." $w[year]<br>
        $jabatanbaak
        <br><br><br><br><br><br> 
        $namabaak
        
        </td>
 
      </tr>
 
    </table>
    
    </td>
 


  </tr>  
<table>
";
 
?>
