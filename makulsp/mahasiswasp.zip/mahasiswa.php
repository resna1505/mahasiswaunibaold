<?
if ($aksi=="hapus") {
cekhaktulis($kodemenu);
//// Di sini harus ada cukup banyak syarat ////////////////////////////////
	$q="DELETE FROM pengambilanmksp WHERE 
 			IDMAKUL='$idmakulhapus' AND
			TAHUN='$tahunhapus' AND
			SEMESTER='$semesterhapus' AND
			IDMAHASISWA='$idmahasiswahapus'
	
	";
	doquery($q,$koneksi) ;
	$ketlog="Hapus Pengambilan Mata Kuliah dengan ID Makul=$idmakulhapus, 
	Tahun Ajaran=".($tahunhapus-1)."/$tahunhapus,
	Semester=".$arraysemester[$semesterhapus].",
	ID Mahasiswa=$idmahasiswahapus ";
	buatlog(26);
	if (sqlaffectedrows($koneksi)>0) {
		$errmesg="Data Pengambilan M-K Mahasiswa dengan ID = '$idhapus' berhasil dihapus";
    				$q="DELETE FROM trnlmsp WHERE 
    				NIMHSTRNLM='$idmahasiswahapus'
    				AND THSMSTRNLM='".($tahunhapus-1)."$semesterhapus'
    				AND KDKMKTRNLM='$idmakulhapus'
    				 
    				";	
	           doquery($q,$koneksi);


	} else {
		$errmesg="Data Pengambilan M-K Mahasiswa dengan ID = '$idhapus' tidak berhasil dihapus";
	}
	$aksi="tampilkan";
}

if ($aksi=="update"  && $REQUEST_METHOD==POST) {
cekhaktulis($kodemenu);
	if(trim($idmahasiswa)=="" || !isdataada($idmahasiswa,"mahasiswa")) {
		$errmesg="NIM harus diisi atau tidak ada Mahasiswa dengan NIM '$idmahasiswa'";
	} elseif(trim($idmakul)==""  || !isdataada($idmakul,"makul")) {
		$errmesg="Kode Mata Kuliah harus diisi  atau tidak ada Mata Kuliah dengan Kode '$idmakul'";
	} elseif(trim($data[semester])=="" || !isintegerpositif($data[semester])) {
		$errmesg="Semester Mata Kuliah harus diisi dengan angka > 0";
	} elseif(trim($data[kelas])=="") {
		$errmesg="Kode Kelas harus diisi";
	} else {
			$q="SELECT SEMESTER FROM makul WHERE ID='$data[idmakul]'";
			$h=doquery($q,$koneksi);
			$d=sqlnumrows($h);
		    $q="
			UPDATE pengambilanmksp SET 
 			IDMAKUL='$idmakul',
			IDMAHASISWA='$idmahasiswa',
			TAHUN='$data[tahun]',
			SEMESTERMAKUL='$d[SEMESTER]',
			SEMESTER='$data[semester]',
			KELAS='$data[kelas]'
			WHERE 
 			IDMAKUL='$idmakulupdate' AND
			TAHUN='$tahunupdate' AND
			SEMESTER='$semesterupdate' AND
			IDMAHASISWA='$idmahasiswaupdate'
		";
		doquery($q,$koneksi); 
		$ketlog="Update Pengambilan Mata Kuliah dengan ID Makul=$idmakulupdate, 
		Tahun Ajaran=".($tahunupdate-1)."/$tahunupdate,
		Semester=".$arraysemester[$semesterupdate].",
		ID Mahasiswa=$idmahasiswaupdate ";
		buatlog(25);
		//echo mysql_error();
		if (sqlaffectedrows($koneksi)>0) {
			$errmesg="Data Pengambilan M-K Mahasiswa berhasil diupdate";
 			$idmakulupdate=$idmakul;
			$kelasupdate=$data[kelas];
			$tahunupdate=$data[tahun];
			$semesterupdate=$data[semester];
 		} else {
			$errmesg="Data Pengambilan M-K Mahasiswa tidak diupdate. Data memang tidak diubah atau 
			Seorang Mahasiswa tidak dapat mengambil dua mata kuliah yang sama pada tahun ajaran yang sama";
		}
	}
	
 	$aksi="formupdate";
}
if ($aksi=="formupdate") {
cekhaktulis($kodemenu);
	$q="SELECT * FROM pengambilanmksp WHERE 
 			IDMAKUL='$idmakulupdate' AND
			TAHUN='$tahunupdate' AND
			IDMAHASISWA='$idmahasiswaupdate'
	";
	$h=doquery($q,$koneksi);
	if (sqlnumrows($h)>0) {
		printjudulmenu("Update KRS Semester Pendek Mahasiswa");
		printmesg($errmesg);
		$d=sqlfetcharray($h);
		
		echo "
		<form name=form action=index.php method=post>
		<table class=form>".
		createinputhidden("pilihan",$pilihan,"").
		createinputhidden("aksi","update","").
 		createinputhidden("idmakulupdate","$idmakulupdate","").
		createinputhidden("idmahasiswaupdate","$idmahasiswaupdate","").
		createinputhidden("tahunupdate","$tahunupdate","").
		createinputhidden("semesterupdate","$semesterupdate","").
  		"<tr >
			<td class=judulform> NIM  Mahasiswa *</td>
			<td>".
		createinputtext("idmahasiswa","$d[IDMAHASISWA]"," class=masukan  size=20").
			"
			<a 
			href=\"javascript:daftarmhs('form,wewenang,idmahasiswa',
			document.form.idmahasiswa.value)\" >
			daftar mahasiswa
			</a>
			
			</td>
		</tr>".
 		"<tr class=judulform>
			<td>Kode Mata KUliah *</td>
			<td>".
		createinputtext("idmakul","$d[IDMAKUL]"," class=masukan  size=10").
			"
			<a 
			href=\"javascript:daftarmakul('form,wewenang,idmakul',
			document.form.idmakul.value)\" >
			daftar mata kuliah
			</a>
			
			
			</td>
		</tr>".
 		"<tr class=judulform>
			<td>Tahun Ajaran</td>
			<td>".
		createinputtahunajaran("data[tahun]","$d[TAHUN]"," class=masukan  cols=50 rows=4").
			"</td>
		</tr>".
  		"<tr class=judulform>
			<td>Semester</td>
			<td>".
			createinputselect("data[semester]",$arraysemester,$semesterupdate,''," class=masukan").
			"</td>
		</tr>".
   		"<tr class=judulform>
			<td>Kelas</td>
			<td>".
			createinputtext("data[kelas]","$d[KELAS]"," class=masukan size=4").
			"</td>
		</tr>
 			<tr>
				<td colspan=2>
					<input type=submit value='Update' class=masukan>
					<input type=reset value='Reset' class=masukan>
				</td>
			</tr>
			</table>
			</form>
			<script>
 				form.idmahasiswa.focus();
			</script>
		";
	} else {
		$errmesg="Data Pengambilan M-K Mahasiswa  tidak ada";
		$aksi="";
	}
}


if ($aksi=="updatemk"  && $REQUEST_METHOD==POST) {
cekhaktulis($kodemenu);

/// AMbil Data Syarat KRS ///

/////////////////////////////
	if (is_array($data)) {
		$jmlupdate=0;
		$jmlhapus=0;

		for ($j=0;$j<$count;$j++) {
			 $ttmp="idambil_$j";
 			$idambil[$$ttmp]=1;
 		}


		foreach ($datax as $k=>$v) {
			//echo "Hooi";
			if ($idambil[$k]==1) {
		  	$q="INSERT INTO  pengambilanmksp 
				(IDMAHASISWA,IDMAKUL,TAHUN,KELAS,SEMESTER,SEMESTERMAKUL,SKSMAKUL) 
				VALUES('$idmahasiswa','$k','$data[tahun]','$v[kelas]',$data[semester],
				'$v[semester]','$v[sks]')
				";
				doquery($q,$koneksi);
				if (sqlaffectedrows($koneksi)<=0) {
					$q="UPDATE pengambilanmksp 
					SET 
						KELAS='$v[kelas]',
						SEMESTER='$data[semester]',
						SEMESTERMAKUL='$v[semester]',						
						SKSMAKUL='$v[sks]'
					WHERE
					IDMAHASISWA='$idmahasiswa'
					AND TAHUN='$data[tahun]'
					AND IDMAKUL='$k'";	
					
					doquery($q,$koneksi);
					if (sqlaffectedrows($koneksi)>0) {
						doquery($q,$koneksi); 
						$ketlog="Update Pengambilan Mata Kuliah dengan ID Makul=$k, 
						Tahun Ajaran=".($data[tahun]-1)."/$data[tahun],
						Semester=".$arraysemester[$data[semester]].",
						ID Mahasiswa=$idmahasiswa ";
						buatlog(25);
  					$sem=$data[semester];
  					$tahunlama=$data[tahun];
						$jmlupdate++;
					}
				} else {
					$jmlupdate++;
 					$ketlog="Tambah Pengambilan Mata Kuliah dengan ID Makul=$k, 
						Tahun Ajaran=".($data[tahun]-1)."/$data[tahun],
						Semester=".$arraysemester[$data[semester]].",
						ID Mahasiswa=$idmahasiswa ";
					buatlog(24);
					$sem=$data[semester];
					$tahunlama=$data[tahun];
				}
			} else {
				$q="DELETE FROM pengambilanmksp WHERE 
				IDMAHASISWA='$idmahasiswa'
				AND TAHUN='$data[tahun]'
				AND IDMAKUL='$k'
				AND SEMESTER='$data[semester]'
				";	
				doquery($q,$koneksi);
				if (sqlaffectedrows($koneksi)>0) {
 					$ketlog="Hapus Pengambilan Mata Kuliah dengan ID Makul=$k, 
						Tahun Ajaran=".($data[tahun]-1)."/$data[tahun],
						Semester=".$arraysemester[$data[semester]].",
						ID Mahasiswa=$idmahasiswa ";
					buatlog(26);
    				$q="DELETE FROM trnlmsp WHERE 
    				NIMHSTRNLM='$idmahasiswa'
    				AND THSMSTRNLM='".($data[tahun]-1)."$data[semester]'
    				AND KDKMKTRNLM='$k'
    				 
    				";			
            	doquery($q,$koneksi);			
					$q="SELECT IDMAHASISWA FROM pengambilanmksp 
          WHERE 
          IDMAHASISWA='$idmahasiswa'
				  AND TAHUN='$data[tahun]'
          AND SEMESTER='$data[semester]'";
					$h=doquery($q,$koneksi);
					if (sqlnumrows($h)<=0) {
 
          }
					
					$jmlhapus++;
				}
			}
 		}
 		if ($jmlupdate>0) {
 			$errmesg="Pengambilan Mata Kuliah Telah ditambahkan/diupdate sebanyak $jmlupdate buah";
 		}
 		if ($jmlhapus>0) {
 			$errmesg.="<br>Pengambilan Mata Kuliah Telah Dihapus sebanyak $jmlhapus buah";
 		}
	}
 	$aksi="tampiledit";
}

if ($aksi=="tampiledit") {
  $tmpcetak="";
cekhaktulis($kodemenu);
	if(trim($idmahasiswa)=="" || !isdataada($idmahasiswa,"mahasiswa")) {
		$errmesg="NIM harus diisi atau tidak ada Mahasiswa dengan NIM '$idmahasiswa'";
		$aksi="tambahawal";
	} elseif(!ismahasiswaaktif($idmahasiswa)) {
		$errmesg="Data tidak dapat diproses karena mahasiswa dengan ID '$idmahasiswa' DO/Lulus/Cuti";
		$aksi="tambahawal";
	} elseif(trim($data[semester])=="" || !isintegerpositif($data[semester])) {
		$errmesg="Semester Mata Kuliah harus diisi dengan angka > 0";
		$aksi="tambahawal";
 	} else  {
 	 	  if ($prodis!="") {
 	    $qfilter=" AND mahasiswa.IDPRODI='$prodis' ";
		}

		$q="
			SELECT mahasiswa.NAMA,ANGKATAN,IDPRODI,KELAS AS KELASDEFAULT,
      KDPSTMSMHS,KDJENMSMHS 
			
			FROM  mahasiswa,msmhs
			WHERE
			mahasiswa.ID=msmhs.NIMHSMSMHS AND
		  mahasiswa.ID='$idmahasiswa'
		  $qfilter
 		";
      		$h=doquery($q,$koneksi);
 		if (sqlnumrows($h)<=0) {
 			$errmesg="Data Mahasiswa / Data Dosen Wali Tidak Ada";
 			$aksi="tambahawal";
 		} else {
 			$d=sqlfetcharray($h);
 			if ($data[semester]!=3) {
 				$semesterx="".((($data[tahun]-1-$d[ANGKATAN])*2)+$data[semester])."";
 				$kurawal="(";
 				$kurtutup=")";
 				//echo "(($data[tahun]-1-$d[ANGKATAN])*+$data[semester]))";
 			}
 			if ($data[semester]!=3 && $semesterx <=0) {
				$errmesg="Tahun Ajaran salah. Mahasiswa ybs belum masuk pada tahun ajaran yang dipilih.";
				$aksi="tambahawal"; 			
				} else {
 			printjudulmenu("Edit Data KRS Semester Pendek");
 			printmesg($errmesg);

 			$angkatanx=$d[ANGKATAN];
        

               $q="SELECT sksmaksimumsp.* 
            FROM sksmaksimumsp ,mahasiswa
            WHERE 
            mahasiswa.IDPRODI=sksmaksimumsp.IDPRODI
              AND mahasiswa.ID='$idmahasiswa'
            ";
            $hs=doquery($q,$koneksi);
            echo mysql_error();
            if (sqlnumrows($hs)>0) {
              $ds=sqlfetcharray($hs);
              $sksmaksimum=$ds[SKS];
              $semesteracuan=$ds[SEMESTER];
            }
        
        $thnlalu=$data[tahun]-1;
        $semlalu=$data[semester];
        
        if ($semesteracuan > 0) {
          if ($semlalu % 2 ==0 ) { // Genap       
            $thnlalu=$thnlalu-floor($semesteracuan/2);
            if ($semesteracuan % 2 ==0) {
              $semlalu=2;
            } else {
              $semlalu=1;
            }
          } else {// Ganjil
            $thnlalu=$thnlalu-ceil($semesteracuan/2);
            if ($semesteracuan % 2 ==0) {
              $semlalu=1;
            } else {
              $semlalu=2;
            }
          }
        }

          if ($data[semester]==2) {
            $tahunsemesterlalu=($data[tahun]-1)."1";
          } else {
            $tahunsemesterlalu=($data[tahun]-2)."2";
          }


    		     $q="
    			SELECT NLIPSTRAKM
    			FROM  trakm
    			WHERE
    		  NIMHSTRAKM='$idmahasiswa' AND
    		  THSMSTRAKM<='$thnlalu$semlalu'
    		  ORDER BY THSMSTRAKM DESC LIMIT 0,1
    		  
     		";
     		$hip=doquery($q,$koneksi);
        if (sqlnumrows($hip)>0) {
          $dip=sqlfetcharray($hip);
          $ips=$dip[NLIPSTRAKM];
        } else {
          $ips="Tidak ada";
        }
        $semesterkrs=$semesterx;
			$tmpcetak.= "
				<br>
				<table class=form>
					<tr>
						<td class=judulform>Tahun Ajaran</td>
						<td >".($data[tahun]-1)."/$data[tahun]</td>
					</tr>
					<tr>
						<td class=judulform>Semester</td>
						<td > $semesterx $kurawal ".$arraysemester[$data[semester]]." $kurtutup </td>
					</tr>
					<tr>
						<td class=judulform>NIM</td>
						<td >$idmahasiswa</td>
					</tr>
					<tr>
						<td >Nama</td>
						<td >$d[NAMA]</td>
					</tr>
					<tr>
						<td >Angkatan</td>
						<td >$d[ANGKATAN]</td>
					</tr>
					<tr>
						<td >IP ";
						if ($semesteracuan>0) {
              $tmpcetak.= "$semesteracuan Semester Lalu";
             } else {
              $tmpcetak.= "semester ini";
             }            
            $tmpcetak.= "</td>
						<td ><b>$ips</td>
					</tr>
 
				</table>
			";
			
//// Edit Rincian Data Pengambilan MK
    $idprodimhs=$d[IDPRODI];
    $kodeprodi=$d[KDPSTMSMHS];
    $kodejenjang=$d[KDJENMSMHS];
/////////////////////////////////////    

    $q="SELECT * FROM syaratkrssp WHERE IDPRODI='$idprodimhs' ORDER BY SKS DESC";
    $hkrs=doquery($q,$koneksi);
    if (sqlnumrows($hkrs)>0) {
      while ($dkrs=sqlfetcharray($hkrs)) {
        $arraysyaratkrs["$dkrs[SKS]"]="$dkrs[IPS]"; 
      }    
    }
    
/////////////////////////////////////    
		if ($idprodi=="") {
			$idprodi=$d[IDPRODI];
		}
		$tmpcetak.= "
		<form  action=index.php method=post>
			".createinputhidden("idmahasiswa","$idmahasiswa","")."
			".createinputhidden("aksi","$aksi","")."
			".createinputhidden("pilihan","$pilihan","")."
			".createinputhidden("pilihtampil","$pilihtampil","")."
			".createinputhidden("data[tahun]","$data[tahun]","")."
			".createinputhidden("data[semester]","$data[semester]","")."
			".createinputhidden("idprodi","$idprodi","")."

		</form>";
/*
			<table class=form>
				<tr>
				<td class=judulform align=left>Jurusan / Program Studi Mata Kuliah
				</td>
				<td>".createinputselect("idprodi",$arrayprodidep2,"$idprodi","","class=masukan")."
				<input type=submit value='ganti' class=masukan>
				</td>
				</tr>
			</table>
,
		 SEMESTBKMK+0 AS SEMESTER
*/
	  	 $q="SELECT makul.ID,makul.NAMA  ,THSMSTBKMK,
      tbkmksp.KDWPLTBKMK,SKSMKTBKMK AS SKS ,     
      SEMESTBKMK  +0 AS SEMESTER
		FROM makul,tbkmksp
		WHERE
		  makul.ID=tbkmksp.KDKMKTBKMK AND
		  tbkmksp.THSMSTBKMK='".($data[tahun]-1)."$data[semester]' AND
		  tbkmksp.STKMKTBKMK='A' AND
				(  (KDPSTTBKMK='$kodeprodi' AND KDJENTBKMK='$kodejenjang' ))
			ORDER BY SEMESTER,ID
		";
		$hp=doquery($q,$koneksi);
		if (sqlnumrows($hp)<=0) {
			printmesg("Data Mata Kuliah Jurusan / Program Studi  '".$arrayprodidep[$idprodi]."' Tidak Ada");
		} else {
		$tmpcetak.= "
		<form name=form action=index.php method=post>
			".createinputhidden("idmahasiswa","$idmahasiswa","")."
			".createinputhidden("aksi","updatemk","")."
			".createinputhidden("pilihan","$pilihan","")."
			".createinputhidden("idprodi","$idprodi","")."
			".createinputhidden("pilihtampil","$pilihtampil","")."
			".createinputhidden("data[tahun]","$data[tahun]","")."
			".createinputhidden("data[semester]","$data[semester]","");

			$tmpcetak.= "
				<table  class=form>
				<tr align=center class=juduldata>
					<td colspan=8 align=right>
						<a href='#' onClick='cekall();return false;'>[pilih semua]</a>  
						<a href='#' onClick='uncekall();return false;'>[batal pilih semua]</a> 
					<input type=submit class=masukan value='update'>
					</td>
				</tr>
				<tr align=center class=juduldata>
					<td>No</td>
					<td>Kode</td>
					<td>Nama Mata Kuliah</td>
					<td>Wajib/Pilihan</td>
					<td>SKS</td>
					<td>Syarat</td>
 					<td>Kelas</td>
					<td>Ambil</td>
				</tr>
			";
			$i=0;
			$semlama="";
			$startawal=0;
			while ($dp=sqlfetcharray($hp)) {
			   if ($pilihtampil==1 ) 				{
			      // echo "$dp[SEMESTER] $semesterx <br>";
			       if (!($dp[SEMESTER]%2==$semesterx%2)) {
                continue;
             }
         }	
          if ($semlama!=$dp[SEMESTER]) {
						if ($semlama!="") {
							$tmpcetak.= "
							<tr class=juduldata>
								<td colspan=8 align=right>
									<a href='#' onClick='cekall$semlama();return false;'>[pilih semua]</a>
									<a href='#' onClick='uncekall$semlama();return false;'>[batal pilih semua]</a> <input type=submit class=masukan value='update'>
									<script>
										var start$semlama=$startawal;
						 				var count$semlama=$i;
										function cekall$semlama() {
											var i=0;
											for (i=start$semlama;i<count$semlama ;i++) {
												  
												eval('form.idambil_'+i+'.checked=true');
						 					}
						 				}
										function uncekall$semlama() {
											var i=0;
											for (i=start$semlama;i<count$semlama ;i++) {
												eval('form.idambil_'+i+'.checked=false');
						 					}
						 				}
						 			</script>
									
								</td>
							</tr>							
							";
							$startawal=$i;
						}
						$semlama=$dp[SEMESTER];
 						$tmpcetak.= "
 						$tmp
							<tr class=juduldata>
								<td colspan=8>Semester $dp[SEMESTER] </td>
							</tr>
						";
					}
				$kelas=kelas($i);
				$q="SELECT KELAS,SEMESTER FROM pengambilanmksp WHERE
				IDMAHASISWA='$idmahasiswa' AND
				TAHUN='$data[tahun]' AND
				SEMESTER='$data[semester]' AND
				IDMAKUL='$dp[ID]'
				";
				$hx=doquery($q,$koneksi);
				unset($dx);
				unset($cekdx);
				if (sqlnumrows($hx)>0) {
					$dx=sqlfetcharray($hx);
					$cekdx="checked";
				} else {
					$dx[KELAS]=$d[KELASDEFAULT];
				}
				$q="SELECT syaratpengambilanmksp.*  
        FROM syaratpengambilanmksp  
        WHERE
        syaratpengambilanmksp.IDMAKUL='$dp[ID]' AND
        syaratpengambilanmksp.TAHUN='$data[tahun]'
        AND syaratpengambilanmksp.SEMESTER='$data[semester]'
         
         ";
 
				$hss=doquery($q,$koneksi);
				 
				$daftarsyarat="";
				$syaratok=1;
				$jmlsyarat=sqlnumrows($hss);
				$totalsyarat=0;
				if (sqlnumrows($hss)>0) {
				   $syaratok=0;
				  while ($dss=sqlfetcharray($hss)) {
            $daftarsyarat.="$dss[IDSYARAT], $dss[NILAI], $dss[BOBOT] <br>";
    				    $q="SELECT pengambilanmk.NILAI,BOBOT,SIMBOL  
            FROM pengambilanmk  
            WHERE
            pengambilanmk.IDMAKUL='$dss[IDSYARAT]' AND
            IDMAHASISWA='$idmahasiswa'
            AND BOBOT >= $dss[BOBOT]
             ";
             /*
                         pengambilanmk.TAHUN='$data[tahun]'
            AND  pengambilanmk.SEMESTER='$data[semester]'
            AND 
             */
             $hss2=doquery($q,$koneksi);
             if (sqlnumrows($hss2)>0) {
              $totalsyarat++;
             }
          }
        }
        if ($totalsyarat>=$jmlsyarat && $jmlsyarat>0) {
          $syaratok=1;
        }
				$tmpcetak.= "
					<tr align=center $kelas>
						<td>  ".($i+1)."
						".createinputhidden("datax[$dp[ID]][semester]","$dp[SEMESTER]","class=masukan size=2")."
						".createinputhidden("datax[$dp[ID]][sks]","$dp[SKS]","class=masukan size=2")."
						</td>
						<td>$dp[ID]</td>
						<td align=left>$dp[NAMA]   </td>
						<td align=center>".$arrayjenismk[$dp[KDWPLTBKMK]]."</td>
						<td>$dp[SKS]  </td>
						<td nowrap>$daftarsyarat</td>";
            if ($syaratok==1) {
            $tmpcetak.=  "
 						<td>".createinputtext("datax[$dp[ID]][kelas]","$dx[KELAS]","class=masukan size=2")."</td>
						<td>".createinputcek("idambil_$i","$dp[ID]","","$cekdx","class=masukan")."</td>";
						} else {
						  $tmpcetak.=  "<td colspan=2 align=center nowrap><b>tidak memenuhi syarat</td>";
            } 
            $tmpcetak.=  "
					</tr>
				";
				$i++;
			}
							$tmpcetak.= "
							<tr class=juduldata>
								<td colspan=8 align=right>
									 <a href='#' onClick='cekall$semlama();return false;'>[pilih semua]</a>
									<a href='#' onClick='uncekall$semlama();return false;'>[batal pilih semua]</a> <input type=submit class=masukan value='update'>
									<script>
										var start$semlama=$startawal;
						 				var count$semlama=$i;
										function cekall$semlama() {
											var i=0;
											for (i=start$semlama;i<count$semlama ;i++) {
												  
												eval('form.idambil_'+i+'.checked=true');
						 					}
						 				}
										function uncekall$semlama() {
											var i=0;
											for (i=start$semlama;i<count$semlama ;i++) {
												eval('form.idambil_'+i+'.checked=false');
						 					}
						 				}
						 			</script>
									
								</td>
							</tr>							
							";

			$tmpcetak.= "

			</table>

 				<input type=hidden name=count value='$i'>


			
			</form>

			<script>
 				var count=$i;
				function cekall() {
					var i=0;
					for (i=0;i<count ;i++) {
						 
						eval('form.idambil_'+i+'.checked=true');
 					}
 				}
				function uncekall() {
					var i=0;
					for (i=0;i<count ;i++) {
						eval('form.idambil_'+i+'.checked=false');
 					}
 				}
 			</script>
			";
		}
			
//// Rincian Data Pengambilan MK Mahasiswa YBS			
			$q="
				SELECT 
				pengambilanmksp.*,
				makul.NAMA,
				SKSMAKUL AS SKS
				FROM pengambilanmksp,makul
				WHERE
				pengambilanmksp.IDMAHASISWA='$idmahasiswa'
				AND
				pengambilanmksp.IDMAKUL=makul.ID
				ORDER BY 
				pengambilanmksp.TAHUN,pengambilanmksp.SEMESTER
			";
			$h=doquery($q,$koneksi); 
			$tmpcetak.= mysql_error();
			if (sqlnumrows($h)<=0) {
				printmesg("Data Pengambilan Mata Kuliah belum ada<br><BR>");
			} else {
				$tmpcetak.="<br><br>
        				<form action=cetakkrs.php method=post target=_blank>
				  <input type=hidden name=idmahasiswaupdate value='$idmahasiswa'>
				  <input type=hidden name=tahunupdate value='$data[tahun]'>
          <input type=hidden name=semesterupdate value='$data[semester]'>
          <input type=submit value='Cetak KRS'>
				</form>

        <br><b>Data Mata Kuliah Yang Telah Diambil</b><br>";
				$tmpcetak.= "
				
					<table class=form>
					<tr class=juduldata align=center>
						<td>No</td>
						<td>Kode</td>
						<td>Nama M-K</td>
						<td>SKS</td>
						<td>Tahun Ajaran</td>
						<td>Sem M-K</td>
						<td>Kelas</td>
					</tr>
				";
				$i=1;
				$semlama="";
				$tahunlama="";
				while ($d=sqlfetcharray($h)) {
		 				$semesterx=((($d[TAHUN]-1-$angkatanx)*2)+$d[SEMESTER]);
		 				$semestertulis=$semesterx;
	 					$kurawal="(";
	 					$kurakhir=")";

	 				if ($d[SEMESTER]==3) {
	 					$semesterx+=0.5;
	 					$semestertulis="";
	 					$kurawal=$kurakhir="";
	 				}
					$tmp="";
					if ($semlama!=$semesterx) {
						if ($semlama!="") {
							$tmp= "
								<tr class=juduldata >
									<td align=right colspan=3>Total SKS Semester</td>
									<td align=center>$total[$semlama]</td>
									<td colspan=3></td>
								</tr>";
								
					   
 						}
						$semlama=$semesterx;
 						$tmpcetak.= "
 						$tmp
							<tr class=juduldata>
								<td colspan=8>Semester $semestertulis  
								$kurawal ".$arraysemester[$d[SEMESTER]]." $kurakhir</td>
							</tr>";
					}
					$kelas=kelas($i);
					
					$tmpcetak.="
					<tr $kelas>
						<td align=center>$i</td>
						<td>$d[IDMAKUL] </td>
						<td>$d[NAMA]</td>
						<td align=center>$d[SKS]</td>
						<td align=center>".($d[TAHUN]-1)."/$d[TAHUN]</td>
						<td align=center>$d[SEMESTERMAKUL] </td>
						<td align=center>$d[KELAS]</td>
					</tr>";
					 $totalsks+=$d[SKS];
						$total[$semesterx]+=$d[SKS];





            $tahunlama=$d[TAHUN];
              $sem=$d[SEMESTER]%2;
            if ($sem==0) {
              $sem=2;
            }//Genap
            $idmakul=$d[IDMAKUL];
            
            include "editrnlm.php";	
            


            
					$i++;
				}
				if ($semlama!="") {
					$tmpcetak.= "
						<tr class=juduldata >
							<td align=right colspan=3>Total SKS Semester</td>
							<td align=center>$total[$semlama]  </td>
							<td colspan=3></td>
						</tr>";
 
				}
				$tmpcetak.= " 
					<tr class=juduldata>
						<td align=right colspan=3>Total SKS</td>
						<td align=center>$totalsks</td>
						<td colspan=3></td>
					</tr>";

					
				$tmpcetak.= "
					</table>
					<br>
				";
						/// Periksa Syarat KRS ///

						if ($total[$semesterkrs]+0==0) {
 

            }


            if ($total[$semesterkrs]>$sksmaksimum && $sksmaksimum>0) {
                   printmesg("Peringatan : SKS diambil sebanyak ".$total[$semesterkrs].", SKS maksimum yang dapat diambil adalah $sksmaksimum.");
            
            }
						if (is_array($arraysyaratkrs)) {
  						foreach ($arraysyaratkrs as $k=>$v) {
                if ($total[$semesterkrs] < $k ) {
                  continue;
                } else {
                  if ($ips < $v ) {
                    printmesg("Peringatan : SKS diambil sebanyak ".$total[$semesterkrs].", syarat SKS >= $k adalah IPS $semesteracuan semester yg lalu minimal $v. IPS yg lalu mahasiswa adalah $ips.");
                    break;
                  }
                }
              }
            }						
						
						//////////////////////////
				
			}
			}
		}
	}	
	echo $tmpcetak;
}

if ($aksi=="tambahawal") {
cekhaktulis($kodemenu);
 		printjudulmenu("Edit Data Pengambilan M-K Mahasiswa");
		printmesg($errmesg);
 		
		echo "
		<form name=form action=index.php method=post>
		<table class=form>".
		createinputhidden("pilihan",$pilihan,"").
		createinputhidden("aksi","tampiledit","").
  		"<tr class=judulform>
			<td class=judulform>NIM *</td>
			<td>".
		createinputtext("idmahasiswa",$idmahasiswa," class=masukan  size=20").
			"
			<a 
			href=\"javascript:daftarmhs('form,wewenang,idmahasiswa',
			document.form.idmahasiswa.value)\" >
			daftar mahasiswa
			</a>
			
			</td>
		</tr>".
  		"<tr class=judulform>
			<td>Tahun Ajaran</td>
			<td>".
		createinputtahunajaran("data[tahun]",$data[tahun]," class=masukan  cols=50 rows=4").
			"</td>
		</tr>
  		<tr class=judulform>
			<td>Semester</td>
			<td>".
			createinputselect("data[semester]",$arraysemester,"$data[semester]",''," class=masukan").
			"</td>
		</tr> 
 
  		<tr class=judulform>
			<td>Filter Mata Kuliah</td>
			<td>
        <input type=radio name=pilihtampil value=0 >Tampilkan semua mata kuliah <br>
        <input type=radio name=pilihtampil value=1 checked >Tampilkan mata kuliah semester ganjil/genap saja
      </td>
		</tr> 
			<tr>
				<td colspan=2>
					<input type=submit value='Edit' class=masukan>
					<input type=reset value='Reset' class=masukan>
				</td>
			</tr>


			</table>
			</form>
			<script>
 				form.idmahasiswa.focus();
			</script>
 		";
 }
 
if ($aksi=="tampilkan") {
	$aksi=" ";
	include "prosestampilmahasiswa.php";
}

if ($aksi=="") { 
	printjudulmenu("Lihat Data Pengambilan M-K Mahasiswa ");
	printmesg($errmesg);
	echo "
		<form name=form action=index.php method=post>
			<input type=hidden name=pilihan value='$pilihan'>
			<input type=hidden name=aksi value='tampilkan'>
			<table class=form>

 			<tr>	
				<td>
					Jurusan / Program Studi Mata Kuliah
				</td>
				<td>
					<select class=masukan name=idprodi>
						<option value=''>Semua</option>";
						foreach ($arrayprodidep as $k=>$v) {
							echo "<option value='$k'>$v</option>";
						}
						echo "
					</select>
				</td>
			</tr>
 			<tr>	
				<td>
					Jurusan / Program Studi Mahasiswa
				</td>
				<td>
					<select class=masukan name=idprodim>
						<option value=''>Semua</option>";
						foreach ($arrayprodidep as $k=>$v) {
							echo "<option value='$k'>$v</option>";
						}
						echo "
					</select>
				</td>
			</tr>


  		<tr >
			<td class=judulform>NIM</td>
			<td>".
		createinputtext("idmahasiswa",$idmahasiswa," class=masukan  size=20").
			"
			<a 
			href=\"javascript:daftarmhs('form,wewenang,idmahasiswa',
			document.form.idmahasiswa.value)\" >
			daftar mahasiswa
			</a>
			
			</td>
		</tr>".
 		"<tr class=judulform>
			<td>Kode Mata Kuliah</td>
			<td>".
		createinputtext("idmakul",$idmakul," class=masukan  size=10").
			"
			<a 
			href=\"javascript:daftarmakul('form,wewenang,idmakul',
			document.form.idmakul.value)\" >
			daftar mata kuliah
			</a>
			
			
			</td>
		</tr> 
 			<tr>	
				<td>
					Tahun Ajaran
				</td>
				<td>";
					$waktu=getdate();
					echo "
						<select name=tahun class=masukan> 
						<option value=''>Semua</option>";
						for ($i=1900;$i<=$waktu[year]+5;$i++) {
 							echo "
							<option value='$i' $cek>".($i-1)."/$i</option>
							";
						}
					echo "
						</select>
				</td>
			</tr>
  		<tr class=judulform>
			<td>Semester</td>
			<td>
 
						<select name=semester class=masukan> 
						<option value=''>Semua</option>";
						foreach ($arraysemester as $k=>$v) {
 							echo "
							<option value='$k' $cek>$v</option>
							";
						}
					echo "
						</select>
			</td>
		</tr> 
		 <tr class=judulform>
			<td>Kelas</td>
			<td>".
		createinputtext("kelas",$kelas," class=masukan  size=4").
			"</td>
		</tr> 
			<tr>
				<td colspan=2>
					<input type=submit value='Tampilkan' class=masukan>
				</td>
			</tr>
		</table>
		</form>
			<script>
 				form.idmahasiswa.focus();
			</script>
	";
}

?>
