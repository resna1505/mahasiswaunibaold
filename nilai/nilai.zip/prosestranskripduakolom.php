<?
 
			  $q="
				SELECT DISTINCT pengambilanmk.IDMAKUL,
				makul.NAMA,makul.JENIS,
				makul.SEMESTER
				FROM pengambilanmk,makul 
				WHERE 
				pengambilanmk.IDMAKUL=makul.ID
				AND IDMAHASISWA='$d[ID]'
				ORDER BY makul.SEMESTER,IDMAKUL
			";
			$hn=doquery($q,$koneksi);
			 $jumlahmakuldiambil=sqlnumrows($hn);
			$jumlahmakuldiambilper2=ceil($jumlahmakuldiambil/2);
			if (sqlnumrows($hn)>0) {
				if ($aksi=="cetak") {
					echo "
					<br>
					<table >
					<tr valign=top>
					<td width=50%>";
				}	
					echo "
					
					<table  $borderx   border=0  >
						<tr class=juduldata$cetak align=center>
	 
							<td>Kode</td>
							<td>Mata Kuliah</td>
							<td>Bobot/<br>SKS<br>(b)</td>
							<td>Nilai</td>
							<td>Nilai<br>Mutu<br>(n)</td>
							<td>Angka<br>Mutu<br>(m)</td>
							<td>(b)x(m)<br><br>(t)</td>
						</tr>
				";
				$i=1;
				$semlama="";
				unset($totals);
				while ($d2=sqlfetcharray($hn)) {
					if ($aksi=="cetak") {
						if ($i==$jumlahmakuldiambilper2+1) {
							echo "
								</table>
							</td>
							<td>
								<table  $borderx  border=0  >
									<tr class=juduldata$cetak align=center>
				 
										<td>Kode</td>
										<td>Mata Kuliah</td>
										<td>Bobot/<br>SKS<br>(b)</td>
										<td>Nilai</td>
										<td>Nilai<br>Mutu<br>(n)</td>
										<td>Angka<br>Mutu<br>(m)</td>
										<td>(b)x(m)<br><br>(t)</td>
									</tr>									
								
							";
							}
					}	
					
					
					
					
					
					$q="SELECT SKSMAKUL FROM pengambilanmk WHERE	
						IDMAHASISWA='$d[ID]'
						AND 
						IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC, SEMESTER DESC
						LIMIT 0,1
					";
					$hxx=doquery($q,$koneksi);
					$dxx=sqlfetcharray($hxx);
					$d2[SKS]=$dxx[SKSMAKUL];
					unset($kp);
					if ($konversisemua==0) {
						unset($kon);
					}
 
					$kelas=kelas($i);
					
				unset($d2[TAHUN]);
				unset($d2[KELAS]);
				unset($ddmk);
					$simbolmax="-";
					$bobot=0;
					$nilai="";
					$nilai2=0;				
 				if ($nilaidiambil==1) {
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						LIMIT 0,1
					";
					$hmk=doquery($q,$koneksi);
					if (sqlnumrows($hmk)>0) {
						$dmk=sqlfetcharray($hmk);
						$bobot=$dmk[BOBOT];
						$simbolmax=$nilai=$dmk[SIMBOL];
						$nilai2=$dmk[NILAI];
						$ddmk[]=$dmk;
    						$semk=$dmk[SEMESTER];
    						$tahunk=$dmk[TAHUN];  						
					}
				} else {
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						 
					";
					$hmk=doquery($q,$koneksi);
					if (sqlnumrows($hmk)>0) {
					   $bobot=0;
						while ($dmk=sqlfetcharray($hmk)) {
						  if ($dmk[BOBOT]>=$bobot) {
                $bobot=$dmk[BOBOT];
    						$simbolmax=$nilai=$dmk[SIMBOL];
    						$nilai2=$dmk[NILAI];
    						$semk=$dmk[SEMESTER];
    						$tahunk=$dmk[TAHUN];      						
              }
							$ddmk[]=$dmk;
						}
 					}
				}
				
 
						if ($simbolmax!="-" && $nilai!="T") {
						  $bobots[$d2[SEMESTER]]+=$d2[SKS];
	 				    $totals[$d2[SEMESTER]]+=$bobot*$d2[SKS];
						  $bobotsemua+=$d2[SKS];
						  $totalsemua+=$bobot*$d2[SKS];
  						$bobots2[$d2[SEMESTER]][$d2[JENIS]]+=$d2[SKS];
   						$totals2[$d2[SEMESTER]][$d2[JENIS]]+=$bobot*$d2[SKS];
 						   $totalbm+=($d2[SKS]*$bobot);
					}
					echo "
							<tr $kelas$cetak align=left>
								<td>$d2[IDMAKUL]</td>
								<td>  ".getnamamk("$d2[IDMAKUL]","".($tahunk-1)."$semk",$d[IDPRODI])."</td>
								<td align=center>$d2[SKS] </td>
								<td align=center>".number_format($nilaiakhir,2)."</td>
 								<td align=center>$nilai</td>
								<td align=center>$bobot</td>
 								<td align=center>".number_format($d2[SKS]*$bobot,2)."  </td>
							</tr>
					";
					/*
///////////////// DIKTI TRNLM /////
              $idmakul=$d2[IDMAKUL];

						 $sem=$d2[SEMESTER]%2;
            if ($sem==0) {$sem=2;}//Genap
            $semkurang=ceil($d2[SEMESTER]/2);
            $tahunlama=$angkatanmhs+($semkurang);
					   include "../makul/editrnlm.php";
					    $q="UPDATE trnlm SET
							  NLAKHTRNLM='$nilai', 
                BOBOTTRNLM='$bobot'
                WHERE
                NIMHSTRNLM='$idmahasiswa'
                AND THSMSTRNLM='".($tahunlama-1)."$sem'
                AND KDKMKTRNLM='$d2[IDMAKUL]'
                ";
                 doquery($q,$koneksi);       
///////////////// END DIKTI TRNLM /////					
					*/
					$i++;
				}

					echo "
							<tr $kelas$cetak  align=left>
								<td colspan=2 align=center><b>JUMLAH</td>
								<td align=center><b>$bobotsemua </td>
								<td align=center> </td>
 								<td align=center> </td>
								<td align=center> </td>
 								<td align=center><b>".number_format($totalbm,2)."</td>
							</tr>
							</table>";
							
							if ($aksi=="cetak") {
							echo "
							</td>
							</tr>
							<tr>
							<td colspan=2>
								
							";
							} else {
								echo "<TABLE>";
							}

				/*
						if ($semlama!="") {
						//echo $totals[$d2[SEMESTER]];
						echo "
						
							<tr align=left>
								<td colspan=2
								style=''
								align=right
								>
								Jumlah SKS 
								</td>
								<td align=center>"
								.number_format($bobots[$semlama],2,'.',',')."
								</td>
								<td colspan=2 >
								Indeks Prestasi : ".number_format(@($totals[$semlama]/$bobots[$semlama]),2,'.',',')."
								</td>
							</tr>
						";
						}
						*/
						//if ($semlama!="") {
						//echo $totals[$d2[SEMESTER]];
						$catatan="";
						if ($d[SKSMIN] > $bobotsemua) {
							//$catatan="Total SKS tidak cukup. Total SKS minimum adalah $d[SKSMIN] SKS<br>";
						}
						
						
						echo "
					</table>
					<table>
						<tr  align=left>
							<td>
								<table  width=600>
									<tr valign=top align=left>
										<td width=50% ><b>Judul Tugas Akhir  </td> 
											<td>: 
										".str_replace("\n","<br>",$d[TA])." </td>
										 
										</tr> 							
 									";
							//echo $d[JENIS]=1;		
							if ($d[JENIS]==0) { /// Biasa
								$ipkku=@($totalsemua/$bobotsemua);
								$ipkkuteks=number_format(@($totalsemua/$bobotsemua),2);
								$tmp=explode(".",$ipkkuteks);
								$tmp1=angkatoteks($tmp[0]);
								$blkkoma=$tmp[1];
								$tmp2="";
								for ($ia=0;$ia<=strlen($blkkoma)-1;$ia++) {
									 //echo $blkkoma[$ia];
									 $tmp2.=$angka[$blkkoma[$ia]+0]." ";
								}
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif (IPK)</td><td>:  $ipkkuteks ($tmp1 koma $tmp2)<br>
										</td></tr>";
							}	 else { /// Profesi
								$ipkku=@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2);
								$ipkkuteks=number_format(@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2),2);
								$tmp=explode(".",$ipkkuteks);
								$tmp1=angkatoteks($tmp[0]);
								$blkkoma=$tmp[1];
								$tmp2="";
								for ($ia=0;$ia<=strlen($blkkoma)-1;$ia++) {
									 //echo $blkkoma[$ia];
									 $tmp2.=$angka[$blkkoma[$ia]+0]." ";
								}							
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif Semester </td><td>:  ".number_format(@($totalsemua/$bobotsemua),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Ujian AKhir Program (UAP)</td><td>:  ".number_format(@($d[IPKUAP]),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Kumulatif </td><td>: $ipkkuteks  ($tmp1 koma $tmp2) <br>
										</td></tr>
										";
								}
 
						$predikat="";
							if (is_array($konpredikat)) {
								//echo "hoooi";
								foreach ($konpredikat as $k=>$v) {
									if ($ipkku>=$v[SYARAT] && $d[MASABELAJAR] <= $v[SYARATW]) {
										$predikat=$v[NAMA];
 										break;
									}
								}
							}

								echo "
									<tr><td>
								Yudisium </td><td>:  $predikat <br>
									</td></tr>
								</table>
								</p>
								<table   class=form>
									<tr valign=top>
										<td width=50% nowrap> ";
if ($konversisemua==1) {
			$q="
				SELECT IDKONVERSI,SIMBOL,NILAI,SYARAT FROM konversiumum
				ORDER BY NILAI DESC
			";
			
			$ha=doquery($q,$koneksi);
			if (sqlnumrows($ha)>0) {
 	  
						echo "
							<table>
									<tr>
											<td><b>Keterangan Mutu Nilai</td></tr>";

 
 				$syaratlama=100;
				while ($da=sqlfetcharray($ha)) {
 
					echo "
  							<tr><td  >$da[SIMBOL] = $da[SYARAT] - $syaratlama </td></tr>
  					";
 					$syaratlama=$da[SYARAT]-0.01;
 
				}			
	 			echo " </table>
				<br><br>";
			}  
}
////// PREDIKAT KELULUSAN ///////

			$q="
				SELECT ID,NAMA,SYARAT,SYARATW FROM konversipredikat
				ORDER BY SYARAT DESC,SYARATW ASC
			";
			
			$ha=doquery($q,$koneksi);
			if (sqlnumrows($ha)>0) {
 
					echo "

						<table>
								<tr>
										<td><b>Predikat Kelulusan</td>
								</tr>
						 "; 
				$syaratlama=4;		
				while ($da=sqlfetcharray($ha)) {
 
					echo "
						<tr >
 
							<td  >  
 						 
 							IPK      $da[SYARAT] - $syaratlama
 							 
 							</td>
 							<td>: $da[NAMA]</td>
 						</tr>
					";
 					$syaratlama=$da[SYARAT]-0.01;
				}			
	 			echo "</table>
				<br><br>";
			}
											

												
												
												echo "
											
												<table>
														<tr>
																<td>*Penjelasan:
																	<br>
																	Nilai IPK: Jumlah Semua Nilai Mata Kuliah / Jumlah Semua SKS</td>
														</tr>
												</table>											
											</td>
										<td width=30%>";
										
		@include "footertranskrip.php";
										
										echo "
										</td>
									</tr>
								</table>
 
						";
						$q="UPDATE mahasiswa SET SKS='$bobotsemua',
						BOBOT='$totalsemua' 
						WHERE
						ID='$d[ID]'";
						doquery($q,$koneksi);
						
 					echo "
 				</td>
 				</tr></table>
 					";
						
						}
				
				if ($diagram==1) {
				   include "../libchart/libchart.php"; 
					if (is_array($totals)) {
 						$xx1=mt_rand();
						
            $q="INSERT INTO gambartemp VALUES('gambardiagram/"."$xx1.png',NOW())";
            doquery($q,$koneksi);
          $chart = new VerticalChart(); 
						foreach ($totals as $k=>$v) {
						   
              	$chart->addPoint(new Point("$k",@($v/$bobots[$k])));
 						}
         	$chart->setTitle("Grafik Perkembangan IP per Semester ($d[ID])");
        	$chart->render("gambardiagram/$xx1.png");		  
            echo "<img  src='gambardiagram/$xx1.png' style='border: 1px solid gray;'/>"; 
					}
				}

?>
