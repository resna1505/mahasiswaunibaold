<?
 
 
			  $q="
				SELECT DISTINCT pengambilanmk.IDMAKUL, 
				makul.NAMA,makul.JENIS,
				makul.SEMESTER
				FROM pengambilanmk,makul 
				WHERE 
				pengambilanmk.IDMAKUL=makul.ID
				AND IDMAHASISWA='$d[ID]'
				ORDER BY makul.SEMESTER,IDMAKUL
			";
			$hn=doquery($q,$koneksi);
			if (sqlnumrows($hn)>0) {
				echo "
					<br>
					<table $border width=600 border=0  >
						<tr class=juduldata$cetak align=center>
	 
							<td>Kode</td>
							<td>Nama Mata Kuliah</td>
							<td>SKS</td>
							<td>Mutu</td>
							<td>Lambang</td>
						</tr>
				";
				$i=1;
				$semlama="";
				unset($totals);
				while ($d2=sqlfetcharray($hn)) {
					$q="SELECT SKSMAKUL,TAHUN FROM pengambilanmk WHERE	
						IDMAHASISWA='$d[ID]'
						AND 
						IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC, SEMESTER DESC
						LIMIT 0,1
					";
					$hxx=doquery($q,$koneksi);
					$dxx=sqlfetcharray($hxx);
					$tahunlama=$d2[TAHUN];
					$d2[SKS]=$dxx[SKSMAKUL];
					unset($kp);
					if ($konversisemua==0) {
						unset($kon);
					}
 					if ($d2[SEMESTER]!=$semlama) {
 						if ($semlama!="") {
 
 						echo "
							<tr >
								<td colspan=2
								style=''
								align=right
								>
								Jumlah SKS 
								</td>
								<td align=center>"
								.number_format($bobots[$semlama],2,'.',',')."
								</td>
								<td colspan=2  >
								Indeks Prestasi : ".number_format(@($totals[$semlama]/$bobots[$semlama]),2,'.',',')."
								</td>
							</tr>
						";
					 
						 $sem=$semlama%2;
            if ($sem==0) {$sem=2;}//Genap
            $semkurang=ceil($semlama/2);
            $tahunlama=$angkatanmhs+($semkurang);
            $idmahasiswa=$d[ID];
						 	include "../makul/edittrakm.php";
					   $q="UPDATE trakm SET
							  NLIPKTRAKM='".number_format(@($totalsemua/$bobotsemua),2)."', 
                SKSTTTRAKM='$bobotsemua'
                WHERE
                NIMHSTRAKM='$d[ID]'
                AND THSMSTRAKM='".($tahunlama-1)."$sem'
                ";
                doquery($q,$koneksi);           
						 
						}
						$kelas=kelas($i);
						$i++;
						echo "
							<tr $kelas$cetak>
								<td colspan=5><b>Semester $d2[SEMESTER]</td>
							</tr>
						";
						$semlama=$d2[SEMESTER];
						
					} 
					$kelas=kelas($i);
				//	$tahunlama=$d2[TAHUN];
				unset($d2[TAHUN]);
				unset($d2[KELAS]);
				unset($ddmk);
					$simbolmax="-";
					$bobot=0;
					$nilai="";
					$nilai2=0;
 				if ($nilaidiambil==1) {
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						LIMIT 0,1
					";
					$hmk=doquery($q,$koneksi);
					if (sqlnumrows($hmk)>0) {
						$dmk=sqlfetcharray($hmk);
						$bobot=$dmk[BOBOT];
						$simbolmax=$nilai=$dmk[SIMBOL];
						$nilai2=$dmk[NILAI];
						$ddmk[]=$dmk;
						
						$semk=$dmk[SEMESTER];
						$tahunk=$dmk[TAHUN];
					}
				} else {
				  $simbolmax="-";
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						 
					";
					$hmk=doquery($q,$koneksi);

					if (sqlnumrows($hmk)>0) {
					   $bobot=0;
						while ($dmk=sqlfetcharray($hmk)) {
						  if ($dmk[BOBOT]>=$bobot) {
                $bobot=$dmk[BOBOT];
    						$simbolmax=$nilai=$dmk[SIMBOL];
    						$nilai2=$dmk[NILAI];

    						$semk=$dmk[SEMESTER];
    						$tahunk=$dmk[TAHUN];

              }
							$ddmk[]=$dmk;
						}
 					}
				}
				
////////////////////////////////////////////////////////////////////////////////////////////
          
	 				if ($simbolmax!="-" && $nilai!="T") {
	 				  $totals[$d2[SEMESTER]]+=$bobot*$d2[SKS];
						$bobots[$d2[SEMESTER]]+=$d2[SKS];
						$bobotsemua+=$d2[SKS];
						$totalsemua+=$bobot*$d2[SKS];
					}
					echo "
							<tr $kelas$cetak align=left>
								<td>$d2[IDMAKUL] </td>
								<td> ".getnamamk("$d2[IDMAKUL]","".($tahunk-1)."$semk",$d[IDPRODI])."</td>
								<td align=center>$d2[SKS] </td>
								<td align=center>$bobot</td>
 								<td align=center>$nilai</td>
							</tr>
					";
					/*
///////////////// DIKTI TRNLM /////
              $idmakul=$d2[IDMAKUL];

						 $sem=$semlama%2;
            if ($sem==0) {$sem=2;}//Genap
            $semkurang=ceil($semlama/2);
            $tahunlama=$angkatanmhs+($semkurang);
					  include "../makul/editrnlm.php";
					     $q="UPDATE trnlm SET
							  NLAKHTRNLM='$nilai', 
                BOBOTTRNLM='$bobot'
                WHERE
                NIMHSTRNLM='$idmahasiswa'
                AND THSMSTRNLM='".($tahunlama-1)."$sem'
                AND KDKMKTRNLM='$d2[IDMAKUL]'
                ";
                doquery($q,$koneksi);       
///////////////// END DIKTI TRNLM /////
            */    
					$i++;
				}
						if ($semlama!="") {
						//echo $totals[$d2[SEMESTER]];
						echo "
					 
						
							<tr >
								<td colspan=2
								style=''
								align=right
								>
								Jumlah SKS 
								</td>
								<td align=center>"
								.number_format($bobots[$semlama],2,'.',',')."
								</td>
								<td colspan=2 >
								Indeks Prestasi : ".number_format(@($totals[$semlama]/$bobots[$semlama]),2,'.',',')."
								</td>
							</tr>
						
						";
						 
						
						 $sem=$semlama%2;
            if ($sem==0) {$sem=2;}//Genap
            $semkurang=ceil($semlama/2);
            $tahunlama=$angkatanmhs+($semkurang);
            
						 	include "../makul/edittrakm.php";
					   $q="UPDATE trakm SET
							  NLIPKTRAKM='".number_format(@($totalsemua/$bobotsemua),2)."', 
                SKSTTTRAKM='$bobotsemua'
                WHERE
                NIMHSTRAKM='$idmahasiswa'
                AND THSMSTRAKM='".($tahunlama-1)."$sem'
                ";
                doquery($q,$koneksi);      
                
                 
                   
						}
						if ($semlama!="") {
						//echo $totals[$d2[SEMESTER]];
						$catatan="";
						if ($d[SKSMIN] > $bobotsemua) {
							//$catatan="Total SKS tidak cukup. Total SKS minimum adalah $d[SKSMIN] SKS<br>";
						}
						
						
						echo "
							</table>
						<table   width=600>
							<tr align=left>
								<td colspan=7>
								<p>
								<br><br>
								<table >
									<tr><td>
										Jumlah Mutu </td><td>: ".number_format($totalsemua,2,'.',',')."
									</td></tr>
									<tr><td>
								Jumlah Kredit </td><td>: ".number_format($bobotsemua,2,'.',',')." <br>
									</td></tr>
									";
							//echo $d[JENIS]=1;		
							if ($d[JENIS]==0) { /// Biasa
								$ipkku=@($totalsemua/$bobotsemua);
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif (IPK)</td><td>:  ".number_format(@($totalsemua/$bobotsemua),2,'.',',')." <br>
										</td></tr>";
							}	 else { /// Profesi
								$ipkku=@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2);
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif Semester </td><td>:  ".number_format(@($totalsemua/$bobotsemua),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Ujian AKhir Program (UAP)</td><td>:  ".number_format(@($d[IPKUAP]),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Kumulatif </td><td>:  ".number_format(@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2),2,'.',',')." <br>
										</td></tr>
										";
								}
						 //echo $d[MASABELAJAR];
						//$ipkku=0;
						 //echo $ipkku;
						$predikat="";
							if (is_array($konpredikat)) {
								//echo "hoooi";
								foreach ($konpredikat as $k=>$v) {
									if ($ipkku>=$v[SYARAT] && $d[MASABELAJAR] <= $v[SYARATW]) {
										$predikat=$v[NAMA];
 										break;
									}
								}
							}

								echo "
									<tr><td>
								Predikat Kelulusan </td><td>:  $predikat <br>
									</td></tr>
								</table>
								</p>
								<table   class=form>
									<tr valign=top>
										<td width=50% ><b>Judul Karya Tulis Ilmiah : </b> <br>
										
                    ".str_replace("\n","<br>",$d[TA])." </td>
										<td width=30%>";
										
		@include "footertranskrip.php";
										
										echo "
										</td>
									</tr>
								</table>
								</p>
								</td>
							</tr>
						";
						$q="UPDATE mahasiswa SET SKS='$bobotsemua',
						BOBOT='$totalsemua' 
						WHERE
						ID='$d[ID]'";
						doquery($q,$koneksi);

				echo "</table>
				";

						}
				
				if ($diagram==1) {
				   include "../libchart/libchart.php"; 
					if (is_array($totals)) {
 						$xx1=mt_rand();
						
            $q="INSERT INTO gambartemp VALUES('gambardiagram/"."$xx1.png',NOW())";
            doquery($q,$koneksi);
          $chart = new VerticalChart(); 
						foreach ($totals as $k=>$v) {
						   
              	$chart->addPoint(new Point("$k",@($v/$bobots[$k])));
 						}
         	$chart->setTitle("Grafik Perkembangan IP per Semester ($d[ID])");
        	$chart->render("gambardiagram/$xx1.png");		  
            echo "<img  src='gambardiagram/$xx1.png' style='border: 1px solid gray;'/>"; 
					}
				}
			} else {
				//$errmesg="Mahasiswa ybs belum mengambil mata kuliah apa pun";
			}

?>
