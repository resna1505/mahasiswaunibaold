<?
 
		

			  $q="
				SELECT DISTINCT pengambilanmk.IDMAKUL,
				makul.NAMA,makul.JENIS,
				makul.SEMESTER
				FROM pengambilanmk,makul 
				WHERE 
				pengambilanmk.IDMAKUL=makul.ID
				AND IDMAHASISWA='$d[ID]'
 				ORDER BY makul.SEMESTER DESC,IDMAKUL 
				LIMIT 0,1
			";
			$hn=doquery($q,$koneksi);
		if (sqlnumrows($hn)>0) {
				$dn=sqlfetcharray($hn);
				$semmax=$dn[SEMESTER];
				echo "
					<br>
					<table border=1 width=600 style='border-collapse:collapse;'  >
						<tr class=juduldata$cetak align=center>
	 
							<td rowspan=2 >Kode</td>
							<td rowspan=2 >Nama Mata Kuliah</td>
							<td rowspan=2 >SKS</td>
 							<td colspan=$semmax>NILAI SEMESTER</td>
						</tr>
						";
						
						echo "<tr class=juduldata$cetak align=center>";
						for ($is=1;$is<=$semmax;$is++) {
							echo "<td align=center>$is</td>";
						}	
						echo "</tr>
						";
						
		$jenislama=-1;
		$arrayjenismakul2=krsort($arrayjenismakul);
				unset($totals);
		foreach ($arrayjenismakul as $kk=>$vv) {
 				echo "
						<tr class=juduldata$cetak align=center $stylepage>
	 
							<td colspan=".(3+$semmax)."  align=left><br>$vv</td>
						</tr>
				";

			  $q="
				SELECT DISTINCT pengambilanmk.IDMAKUL,
				makul.NAMA,makul.JENIS,
				makul.SEMESTER
				FROM pengambilanmk,makul 
				WHERE 
				pengambilanmk.IDMAKUL=makul.ID
				AND IDMAHASISWA='$d[ID]'
				AND makul.JENIS='$kk'
				ORDER BY makul.SEMESTER,IDMAKUL
			";
			$hn=doquery($q,$koneksi);
				$i=1;
				$semlama="";

				while ($d2=sqlfetcharray($hn)) {
					$q="SELECT SKSMAKUL FROM pengambilanmk WHERE	
						IDMAHASISWA='$d[ID]'
						AND 
						IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC, SEMESTER DESC
						LIMIT 0,1
					";
					$hxx=doquery($q,$koneksi);
					$dxx=sqlfetcharray($hxx);
					$d2[SKS]=$dxx[SKSMAKUL];
					unset($kp);
					if ($konversisemua==0) {
						unset($kon);
					}
 					if ($d2[SEMESTER]!=$semlama) {
 
						$semlama=$d2[SEMESTER];
						
					} 
					$kelas=kelas($i);
					
				unset($d2[TAHUN]);
				unset($d2[KELAS]);
				unset($ddmk);
					$simbolmax="-";
					$bobot=0;
					$nilai="";
					$nilai2=0;				
 				if ($nilaidiambil==1) {
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						LIMIT 0,1
					";
					$hmk=doquery($q,$koneksi);
					if (sqlnumrows($hmk)>0) {
						$dmk=sqlfetcharray($hmk);
						$bobot=$dmk[BOBOT];
						$simbolmax=$nilai=$dmk[SIMBOL];
						$nilai2=$dmk[NILAI];						
            $ddmk[]=$dmk;
    						$semk=$dmk[SEMESTER];
    						$tahunk=$dmk[TAHUN];            
					}
				} else {
					$q="SELECT 
						pengambilanmk.TAHUN,
						pengambilanmk.SEMESTER,
						pengambilanmk.KELAS,NILAI,BOBOT,SIMBOL
						FROM pengambilanmk
						WHERE
						IDMAHASISWA='$d[ID]'
						AND IDMAKUL='$d2[IDMAKUL]'
						ORDER BY TAHUN DESC,SEMESTER DESC
						 
					";
					$hmk=doquery($q,$koneksi);
					if (sqlnumrows($hmk)>0) {
					   $bobot=0;
						while ($dmk=sqlfetcharray($hmk)) {
						  if ($dmk[BOBOT]>=$bobot) {
                $bobot=$dmk[BOBOT];
    						$simbolmax=$nilai=$dmk[SIMBOL];
    						$nilai2=$dmk[NILAI];
    						$semk=$dmk[SEMESTER];
    						$tahunk=$dmk[TAHUN];              }
							$ddmk[]=$dmk;
						}
 					}
				}
				
 
						if ($simbolmax!="-" && $nilai!="T") {

						  $bobots[$d2[SEMESTER]]+=$d2[SKS];
	 				    $totals[$d2[SEMESTER]]+=$bobot*$d2[SKS];
						  $bobotsemua+=$d2[SKS];
						  $totalsemua+=$bobot*$d2[SKS];
  						$bobots2[$d2[SEMESTER]][$d2[JENIS]]+=$d2[SKS];
   						$totals2[$d2[SEMESTER]][$d2[JENIS]]+=$bobot*$d2[SKS];
 				}
					echo "
							<tr $kelas$cetak align=left>
								<td>$d2[IDMAKUL]</td>
								<td> ".getnamamk("$d2[IDMAKUL]","".($tahunk-1)."$semk",$d[IDPRODI])."</td>
								<td align=center>$d2[SKS] </td>";
 
 								for ($is=1;$is<=$semmax;$is++) {
 									if($is==$d2[SEMESTER]) {
										echo "<td align=center>$nilai</td>";
									} else {
										echo "<td align=center></td>";
									}
								}	
 

 								echo "
							</tr>
					";
/*
///////////////// DIKTI TRNLM /////
              $idmakul=$d2[IDMAKUL];

						 $sem=$d2[SEMESTER]%2;
            if ($sem==0) {$sem=2;}//Genap
            $semkurang=ceil($d2[SEMESTER]/2);
            $tahunlama=$angkatanmhs+($semkurang);
					   include "../makul/editrnlm.php";
					    $q="UPDATE trnlm SET
							  NLAKHTRNLM='$nilai', 
                BOBOTTRNLM='$bobot'
                WHERE
                NIMHSTRNLM='$idmahasiswa'
                AND THSMSTRNLM='".($tahunlama-1)."$sem'
                AND KDKMKTRNLM='$d2[IDMAKUL]'
                ";
                 doquery($q,$koneksi);       
///////////////// END DIKTI TRNLM /////
	*/				
					$i++;
				}
 
						if ($semlama!="") {
 
						$catatan="";
						if ($d[SKSMIN] > $bobotsemua) {
							//$catatan="Total SKS tidak cukup. Total SKS minimum adalah $d[SKSMIN] SKS<br>";
						}
				}
			}	
					echo "
							<tr $kelas$cetak align=left>
								<td colspan=2>JUMLAH SKS</td>
								<td align=center>$bobotsemua</td>
								";
                $sumbobot=0;
 								for ($is=1;$is<=$semmax;$is++) {
										echo "<td align=center>".$bobots[$is]."</td>";
                    $sumbobot+=$bobots[$is];
        						 $sem=$is%2;
                    if ($sem==0) {$sem=2;}//Genap
                    $semkurang=ceil($is/2);
                    $tahunlama=$angkatanmhs+($semkurang);
                    
        						 	include "../makul/edittrakm.php";
//        							  NLIPKTRAKM='".number_format(@($totalsemua/$bobotsemua),2)."', 
 
        					   $q="UPDATE trakm SET
                       SKSTTTRAKM='$sumbobot'
                        WHERE
                        NIMHSTRAKM='$idmahasiswa'
                        AND THSMSTRAKM='".($tahunlama-1)."$sem'
                        ";
                        doquery($q,$koneksi);         
  								}
  								echo "
							</tr>
					";
					echo "
							<tr $kelas$cetak  align=left>
								<td colspan=3>INDEKS PRESTASI PER SEMESTER</td>
								";
                $sumbobot=$sumkr=0;
 								for ($is=1;$is<=$semmax;$is++) {
										echo "<td align=center> ".number_format(@($totals[$is]/$bobots[$is]),2,'.',',')."</td>";
                    $sumbobot+=$bobots[$is];
                    $sumkr+=$totals[$is];
        						 $sem=$is%2;
                    if ($sem==0) {$sem=2;}//Genap
                    $semkurang=ceil($is/2);
                    $tahunlama=$angkatanmhs+($semkurang);
                    
        						 	include "../makul/edittrakm.php";
//        							  NLIPKTRAKM='".number_format(@($totalsemua/$bobotsemua),2)."', 
 
        					   $q="UPDATE trakm SET
                       NLIPKTRAKM='".number_format(@($sumkr/$sumbobot),2)."'
                        WHERE
                        NIMHSTRAKM='$idmahasiswa'
                        AND THSMSTRAKM='".($tahunlama-1)."$sem'
                        ";
                        doquery($q,$koneksi);         

  								}
  								echo "
							</tr>
					";
						


						echo "
						</table>
						<table width=600>							
						<tr align=left>
								<td colspan=".(3+$semmax).">
								<p>
								<br><br>
								<table >
									<tr><td>
										Jumlah Mutu </td><td>: ".number_format($totalsemua,2,'.',',')."
									</td></tr>
									<tr><td>
								Jumlah Kredit </td><td>: ".number_format($bobotsemua,2,'.',',')." <br>
									</td></tr>
									";
							//echo $d[JENIS]=1;		
							if ($d[JENIS]==0) { /// Biasa
								$ipkku=@($totalsemua/$bobotsemua);
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif (IPK)</td><td>:  ".number_format(@($totalsemua/$bobotsemua),2,'.',',')." <br>
										</td></tr>";
							}	 else { /// Profesi
								$ipkku=@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2);
								echo "
									<tr><td>
										Indeks Prestasi Kumulatif Semester </td><td>:  ".number_format(@($totalsemua/$bobotsemua),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Ujian AKhir Program (UAP)</td><td>:  ".number_format(@($d[IPKUAP]),2,'.',',')." <br>
										</td></tr>
									<tr><td>
										Indeks Prestasi Kumulatif </td><td>:  ".number_format(@((($totalsemua/$bobotsemua)+$d[IPKUAP])/2),2,'.',',')." <br>
										</td></tr>
										";
								}
						 //echo $d[MASABELAJAR];
						//$ipkku=0;
						 //echo $ipkku;
						$predikat="";
							if (is_array($konpredikat)) {
								//echo "hoooi";
								foreach ($konpredikat as $k=>$v) {
									if ($ipkku>=$v[SYARAT] && $d[MASABELAJAR] <= $v[SYARATW]) {
										$predikat=$v[NAMA];
 										break;
									}
								}
							}

								echo "
									<tr><td>
								Predikat Kelulusan </td><td>:  $predikat <br>
									</td></tr>
								</table>
								</p>
								<table   class=form>
									<tr valign=top>
										<td width=50% ><b>Judul Karya Tulis Ilmiah : </b> <br>
										".str_replace("\n","<br>",$d[TA])." </td>
										<td width=30%>";
										
		@include "footertranskrip.php";
										
										echo "
										</td>
									</tr>
								</table>
								</p>
								</td>
							</tr>
						";
						$q="UPDATE mahasiswa SET SKS='$bobotsemua',
						BOBOT='$totalsemua' 
						WHERE
						ID='$d[ID]'";
						doquery($q,$koneksi);

				echo "</table>
				";

						}
				
				if ($diagram==1) {
				   include "../libchart/libchart.php"; 
					if (is_array($totals)) {
 						$xx1=mt_rand();
						
            $q="INSERT INTO gambartemp VALUES('gambardiagram/"."$xx1.png',NOW())";
            doquery($q,$koneksi);
          $chart = new VerticalChart(); 
						foreach ($totals as $k=>$v) {
						   
              	$chart->addPoint(new Point("$k",@($v/$bobots[$k])));
 						}
         	$chart->setTitle("Grafik Perkembangan IP per Semester ($d[ID])");
        	$chart->render("gambardiagram/$xx1.png");		  
            echo "<img  src='gambardiagram/$xx1.png' style='border: 1px solid gray;'/>"; 
					}
				}


?>
