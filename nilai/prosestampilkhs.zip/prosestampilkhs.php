<?
include "../libchart/libchart.php"; 	
	$href.="index.php?maxdata=$maxdata&pilihan=$pilihan&aksi=$aksi&tgllap[tgl]=$tgllap[tgl]&tgllap[bln]=$tgllap[bln]&tgllap[thn]=$tgllap[thn]&";
	if ($idprodi!="") {
		$qfield.=" AND IDPRODI='$idprodi'";
		$qjudul.=" Jurusan/Program Studi '".$arrayprodidep[$idprodi]."' <br>";
		$qinput.=" <input type=hidden name=idprodi value='$idprodi'>";
		$href.="idprodi=$idprodi&";
	}
	if ($iddosen!="") {
		$qfield.=" AND IDDOSEN='$iddosen'";
		$qjudul.=" Dosen Wali '".$arraydosen[$iddosen]."' <br>";
		$qinput.=" <input type=hidden name=iddosen value='$iddosen'>";
		$href.="iddosen=$iddosen&";
	}
	if ($angkatan!="") {
		$qfield.=" AND mahasiswa.ANGKATAN='$angkatan'";
		$qjudul.=" Angkatan '$angkatan' <br>";
		$qinput.=" <input type=hidden name=angkatan value='$angkatan'>";
		$href.="angkatan=$angkatan&";
	}
	if ($id!="") {
		$qfield.=" AND mahasiswa.ID LIKE '%$id%'";
		$qjudul.=" NIM mengandung kata '$id' <br>";
		$qinput.=" <input type=hidden name=id value='$id'>";
		$href.="id=$id&";
	}
	if ($nama!="") {
		$qfield.=" AND mahasiswa.NAMA LIKE '%$nama%'";
		$qjudul.=" Nama mengandung kata '$nama' <br>";
		$qinput.=" <input type=hidden name=nama value='$nama'>";
		$href.="nama=$nama&";
	}
	if ($status!="") {
		$qfield.=" AND mahasiswa.STATUS='$status'";
		$qjudul.=" Status Mahasiswa '".$arraystatusmahasiswa["$status"]."' <br>";
		$qinput.=" <input type=hidden name=status value='$status'>";
		$href.="status=$status&";
	}
	
	if ($sort=="") {
		$sort=" mahasiswa.ID";
	}
	if ($tahun!="") {
		$qinput.=" <input type=hidden name=tahun value='$tahun'>";
		$href.="tahun=$tahun&";
	}
	$qinput.=" <input type=hidden name=semester value='$semester'>";
	if ($semester=="") {
		$semester=1;
		$href.="semester=$semester&";
	}

		$qinput.=" <input type=hidden name=sort value='$sort'>";


 $q="SELECT COUNT(*) AS JML FROM mahasiswa,prodi,departemen  
	WHERE 1=1 $qprodidep5 AND
	mahasiswa.IDPRODI=prodi.ID AND
	prodi.IDDEPARTEMEN=departemen.ID
	$qfieldtambahan2
	$qfield
 	$qfieldx1 
	";
	$h=doquery($q,$koneksi);
	$d=sqlfetcharray($h);
  $total=$d[JML];
  $first=0;
  if (0+$dataperhalaman<=0) {
    $dataperhalaman=1;
  }
  $maxdata=$dataperhalaman;
  include "../paginating.php";	


	$q="SELECT mahasiswa.*,prodi.SKSMIN , 
	prodi.IDDEPARTEMEN, 	prodi.TINGKAT,
	departemen.IDFAKULTAS 
	FROM mahasiswa,prodi,departemen  
	WHERE 1=1 $qprodidep5 AND
	mahasiswa.IDPRODI=prodi.ID AND
	prodi.IDDEPARTEMEN=departemen.ID
	$qfieldtambahan2
	$qfield
	$qfieldx1
	ORDER BY $sort $qlimit";

	$h=doquery($q,$koneksi);
	echo mysql_error();
	if (sqlnumrows($h)>0) {
		if ($aksi!="cetak") {
			printjudulmenu("Kartu Hasil Studi (KHS)");
				echo "$tpage $tpage2";
		}  
		if ($aksi!="cetak") {
			echo "
				<table class=form>
				<tr><td>
			<form target=_blank action='cetakkhs.php'>
 				<input type=submit name=aksi class=tombol value='Cetak'>
  				".createinputhidden("tgllap[tgl]","$tgllap[tgl]","")."
			".createinputhidden("tgllap[bln]","$tgllap[bln]","")."
			".createinputhidden("nilaidiambil","$nilaidiambil","")."
			".createinputhidden("tgllap[thn]","$tgllap[thn]","")."
 			".createinputhidden("dataperhalaman","$dataperhalaman","")."
 				$qinput
			</form>
				</td></tr></table>";
		}
		$totalsemua=0;
		$bobotsemua=0;
			$totals="";
			$bobots="";
		while ($d=sqlfetcharray($h)) {
			$totalsemua=0;
			$bobotsemua=0;
			$totals="";
			$bobots="";
				
				$semesterhitung=
				$kurawal=
				$kurakhir="";
			if ($semester!=3) {
				$semesterhitung=(($tahun-1-$d[ANGKATAN])*2)+$semester;
				$kurawal="(";
				$kurakhir=")";
			}
		if ($aksi=="cetak") {
			echo "<center>
			<h3>Kartu Hasil Studi </h3>
			Tahun Akademik ".($tahun-1)."/$tahun <br><br>";
		}
			 
			/*
			echo "
				<table   class=data$cetak>
					<tr>
						<td class=judulform>NIM</td>
						<td>: $d[ID]</td>
					</tr>
					<tr>
						<td>Nama</td>
						<td>: $d[NAMA]</td>
					</tr>
					<tr>
						<td>Angkatan</td>
						<td>: $d[ANGKATAN]</td>
					</tr>
					<tr>
						<td>Semester</td>
						<td>: $semesterhitung $kurawal ".$arraysemester[$semester]." $kurakhir </td>
					</tr>
					<tr>
						<td>Tahun Akademik</td>
						<td>: ".($tahun-1)."/$tahun</td>
					</tr>
				</table>
			";
			*/
			$idmahasiswa=$d[ID];
			$sem=$semester;
			
			$tahunlama=$tahun;
			echo " 
			
				<center>
			<table   width=600  >
				<tr valign=top>
				<td width=50%>
				<table    >
					<tr align=left>
						<td>Nama</td>
						<td>: $d[NAMA]</td>
					</tr>
					<tr align=left >
						<td class=judulform>NIM</td>
						<td>: $d[ID]</td>
					</tr>
					<tr align=left>
						<td>Semester</td>
						<td>: $semesterhitung $kurawal ".$arraysemester[$semester]." $kurakhir </td>
					</tr>
 				</table>
			</td>
			<td  width=50%>

				<table    >
 					<tr align=left>
						<td>Fakultas</td>
						<td>: ".$arrayfakultas[$d[IDFAKULTAS]]."</td>
					</tr>
					<tr align=left>
						<td>Jurusan</td>
						<td>: ".$arraydepartemen[$d[IDDEPARTEMEN]]."</td>
					</tr>
					<tr align=left>
						<td>Program Studi</td>
						<td>: ".$arrayprodi[$d[IDPRODI]]." (".$arrayjenjang[$d[TINGKAT]].") </td>
					</tr>
				</table>				
				
			</td>
		</table>
	 
			";			
			$angkatanmhs=$d[ANGKATAN];
      $idmahasiswa=$d[ID];						
			include "proseskhs.php";
			if ($aksi!="cetak") {
				echo "<hr>";
			} else {
				echo "<br style='page-break-after:always'>";
			}
		}
	} else {
		$errmesg="Data mahasiswa tidak ada";
		$aksi="";
	}

?>
